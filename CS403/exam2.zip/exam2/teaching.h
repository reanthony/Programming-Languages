#ifndef _TEACHING_H_
#define _TEACHING_H_

#include <string.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include "physician.h"

class teaching : public virtual physician {
public:
    teaching(string first, string last, char physTruncated, double sal, double wRVUs, double rate);
    double getSalary();
    double getwRVUs();
    double getRate();
    char getTruncPhys();
    string getInfo();
    double getEarnings();
private:
    double salary;
    double wrvus;
    double wRVUrate;
    char physT;
};

#endif