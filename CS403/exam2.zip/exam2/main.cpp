#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <limits>

#include "physician.h"
#include "clinical.h"
#include "teaching.h"

using namespace std;

vector<physician*> *readFrom(string filename)  {
    ifstream inFile;
    inFile.open(filename);
    string physicianType;
    vector<physician*> *physicianVect = new vector<physician*>;
    while (inFile >> physicianType)  {
        string firstName, lastName;
        inFile >> firstName >> lastName;
        if (physicianType == "clinical")  {
            double wrvus;
            double rate;
            char physTruncated = 'C';
            inFile >> wrvus >> rate;
            physicianVect -> push_back(new clinical(firstName, lastName, physTruncated, wrvus, rate));
        }
        else if (physicianType == "teaching")  {
            double salary; 
            double wrvus; 
            double rate;
            char physTruncated = 'T';
            inFile >> salary >> wrvus >> rate;
            physicianVect -> push_back(new teaching(firstName, lastName, physTruncated, salary, wrvus, rate));
        }
    }
    return physicianVect;
}

void printPhysicians(vector<physician*> *physicians)  {
    for (unsigned int i = 0; i < physicians->size(); i++)  {
        cout << physicians -> at(i) -> getInfo();
    }
}

int main(int argc, char *argv[])  {
    vector<physician*> *physicians = readFrom(argv[1]);
    if (physicians -> size() == 0)  {
        cout << "There are no physicians." << endl;
        return 0;
    }
    printPhysicians(physicians);
    for (unsigned int i = 0; i < physicians -> size(); i++)  {
        delete physicians -> at(i);
    }
    physicians -> clear();
    return 0;
}
