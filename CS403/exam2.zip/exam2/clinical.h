#ifndef _CLINICAL_H_
#define _CLINICAL_H_

#include <string.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include "physician.h"

class clinical : public virtual physician {
public:
    clinical(string first, string last, char physTruncated, double wRVUs, double rate);
    int getHours();
    double getRate();
    char getTruncPhys();
    string getInfo();
    double getEarnings();
private:
    double wrvus;
    double wRVUrate;
    char physT;
};

#endif