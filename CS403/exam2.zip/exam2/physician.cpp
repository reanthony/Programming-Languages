#include "physician.h"

using namespace std;

physician::physician(string first, string last)  {
    firstName = first;
    lastName = last;
}

physician::~physician()  {}

string physician::getInfo()  {return "";}

double physician::getEarnings()  {return -1;}

string physician::getFirstName()  {
    return this -> firstName;
}

string physician::getLastName()  {
    return this -> lastName;
}

void physician::setFirstName(string first)  {
    this -> firstName = first;
}

void physician::setLastName(string last)  {
    this -> lastName = last;
}
