#include "clinical.h"

clinical::clinical(string first, string last, char physTruncated, double wRVUs, double rate) : physician(first, last)  {
    this -> wrvus = wRVUs;
    this -> wRVUrate = rate;
    this -> physT = physTruncated;
}

int clinical::getHours()  {
    return this -> wrvus;
}

double clinical::getRate()  {
    return this -> wRVUrate;
}

char clinical::getTruncPhys() {
    return this -> physT;
}

string clinical::getInfo()  {
    ostringstream ostream;
    string salIndicator = "";
    if (this -> getEarnings() < 200000)
        salIndicator = "Low";
    else if (this -> getEarnings() > 400000)
        salIndicator = "High";
    else 
        salIndicator = "Mid";
    ostream << this -> getFirstName() << " " << this -> getLastName() << "(" << this -> getTruncPhys() << ") " << this -> getEarnings() << " " << salIndicator << "\n";
    return ostream.str();
}

double clinical::getEarnings()  {           
    double earnings = 0;
    if (wrvus <= 5000) {
        earnings += wrvus * wRVUrate;
    }
    else if (wrvus > 5000) {
        earnings += 5000 * wRVUrate;
        earnings += (wrvus - 5000) * wRVUrate * 1.10;
    }
    return earnings;
}


