#ifndef _PHYSICISIAN_H_
#define _PHYSICISIAN_H_

#include <string.h>
#include <iostream>
#include <sstream>
#include <iomanip>

using namespace std;

class physician  {
public:
    physician(string first, string last);
    string getFirstName();
    string getLastName();
    void setFirstName(string first);
    void setLastName(string last);
    virtual string getInfo();
    virtual double getEarnings();
    virtual ~physician();
private:
    string firstName;
    string lastName;
};

class clincial;
class teaching;

#endif