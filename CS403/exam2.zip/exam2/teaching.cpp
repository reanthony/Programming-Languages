#include "teaching.h"

teaching::teaching(string first, string last, char physTruncated, double sal, double wRVUs, double rate) : physician(first, last)  {
    this -> salary = sal;
    this -> wrvus = wRVUs;
    this -> wRVUrate = rate;
    this -> physT = physTruncated;
}

double teaching::getSalary()  {
    return this -> salary;
}

double teaching::getwRVUs()  {
    return this -> wrvus;
}

double teaching::getRate()  {
    return this -> wRVUrate;
}

char teaching::getTruncPhys()  {
    return this -> physT;
}

string teaching::getInfo()  {
    ostringstream ostream;
    string salIndicator = "";
    if (this -> getEarnings() < 200000)
    salIndicator = "Low";
    else if (this -> getEarnings() > 400000)
    salIndicator = "High";
    else salIndicator = "Mid";
    ostream << this -> getFirstName() << " " << this -> getLastName() << "(" << this -> getTruncPhys() << ") " << this -> getEarnings() << " " << salIndicator << "\n";
    return ostream.str();
} 

double teaching::getEarnings()  {
    double earnings = 0;
    earnings += salary;
    if (wrvus > 3000) {
        earnings += (wrvus - 3000) * wRVUrate;
    }
    return earnings;
}
