#include "Shape.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <limits>
#include <cctype>

using namespace std;

class Cuboid : public Shape {
public:
    Cuboid(string title, double length, double width, double height);
    double getLength() const;
    double getWidth() const;
    double getHeight() const;
    double getArea() const;
    double getVolume() const;
    bool test(const std::vector<std::string>& cond) const;
    string getInfo() const;
    string getTitle() const;
private:
    string nm;
    double len;
    double wid;
    double ht;
};