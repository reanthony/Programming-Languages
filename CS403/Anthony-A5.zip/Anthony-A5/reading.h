#ifndef _READING_H_
#define _READING_H_

#include <vector>
#include "Shape.h"

std::vector<Shape*> *readFrom(std::string filename);

#endif
