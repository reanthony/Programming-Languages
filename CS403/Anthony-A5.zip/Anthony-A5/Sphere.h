#include "Shape.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <limits>
#include <cctype>

using namespace std;

class Sphere : public Shape {
public:
    Sphere(string title, double radius);
    double getRadius() const;
    double getArea() const;
    double getVolume() const;
    bool test(const std::vector<std::string>& cond) const;
    string getInfo() const;
    string getTitle() const;
private:
    string nm;
    double rad;
};