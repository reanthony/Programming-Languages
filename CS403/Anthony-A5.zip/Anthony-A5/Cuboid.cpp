/*
Updated 03/15
 */

//TODO
/*
Test()
Test on cs edu server
*/

#include "Cuboid.h"
#include <string.h>
#include <algorithm>
using namespace std;


Cuboid::Cuboid(string title, double length, double width, double height):Shape("cuboid")  {
    len = length;
    wid = width;
    ht = height;
    nm = title;
}

double Cuboid::getLength() const {return len;}

double Cuboid::getWidth() const {return wid;}

double Cuboid::getHeight() const {return ht;}

string Cuboid::getTitle() const {return nm;}

double Cuboid::getArea() const  {
  return 2 * wid * len + 2 * len * ht + 2 * ht * wid;
}

double Cuboid::getVolume() const  {
  return len * wid * ht;
}

bool Cuboid::test(const std::vector<std::string>& cond) const  {
    std::vector<std::string> cond1 = cond;
    std::reverse(cond1.begin(), cond1.end());
    int order = 0;
    bool results;
    bool result = true;
    string firstcond;
    string op;
    string value;
    //cond;
    int sz = cond1.size();
    if (sz <= 2) return true;

    while (cond1.size() > 0) {
    firstcond =  cond1.back();
    cond1.pop_back();
    //cout << value << "\n";
    op = cond1.back();
    cond1.pop_back();
    //cout << op << "\n";
    value = cond1.back();
    cond1.pop_back();
    //cout << firstcond << "\n";
    //cout << "*************************" << "\n";
    //
    //numVal = (double)((int)(numVal*100))/100;
    //cout << numVal << "\n";
    //cout << this->getArea() << "\n";
    //cout << "*************************" << "\n";
    if (value == "cone")
        order = 1;
    else if (value == "cuboid")
        order = 2;
    else if (value == "cylinder")
        order = 3;
    else if (value == "sphere")
        order = 4;
    else {
        if (value < "cone") order = 0;
        else if (value < "cuboid") order = 1;
        else if (value < "cylinder") order = 2;
        else if (value < "sphere") order = 3;
    }
        
    if (firstcond == "type") {
        if (op == "==" && order == 2)
        results = true;
        else if (op == "!=" && order != 2)
        results = true; 
        //else return true;
        else if (op == ">" && order < 2)
        results = true;
        else if (op == "<" && order > 2)
        results = true;
        else if (op == ">=" && order <= 2)
        results = true;
        else if (op == "<=" && order >= 2)
        results = true;
                else results = false;

    }
   
    
    if(firstcond == "area")  {

        double numVal = stod(value); //(double)((int)(value*100))/100;
        numVal = (int)(numVal);


        if ((op == "==") && (numVal == (this -> getArea()))) 
        results = true;
        //else return false;

        else if ((op == "!=") && ((this -> getArea()) != numVal))
        results = true;
        //else return false;

        else if ((op == ">=") && (numVal <= (this -> getArea())))
        results = true;
        //else return false;

        else if ((op == "<=") && (numVal >= (this -> getArea())))
        results = true;
        //else return false;
        else if ((op == ">") && (numVal < (this -> getArea())))
        results = true;
        //else return false;
        else if ((op == "<") && (numVal > (this -> getArea())))
        results = true;
        else results = false;
    }

    if(firstcond == "volume")  {
        double numVal = stod(value); //(double)((int)(value*100))/100;
        numVal = (int)(numVal);
        if ((op == "==") && (numVal == (this -> getVolume()))) 
        results = true;
        //else return false;

        else if ((op == "!=") && ((this -> getVolume()) != numVal))
        results = true;
        //else return false;

        else if ((op == ">=") && (numVal <= (this -> getVolume())))
        results = true;
        //else return false;

        else if ((op == "<=") && (numVal >= (this -> getVolume())))
        results = true;
        //else return false;
        else if ((op == ">") && (numVal < (this -> getVolume())))
        results = true;
        //else return false;
        else if ((op == "<") && (numVal > (this -> getVolume())))
        results = true;
        else results = false;
   }
    if (results == false) result = false;
    //else result = true;
    }
    return result;
}  

string Cuboid::getInfo() const  {
    string str = this->getName() + ": " + this->getTitle() + ", Length=" +
    to_string(len) + ", Width=" + to_string(wid) + ", Height=" +
    to_string(ht) + "\n\t" + "Surface Area: " + to_string(this->getArea()) + 
    ", Volume: " + to_string(this->getVolume());
    return str;
}

/*
Cuboid: Box#2, Length=10.50, Width=21.00, Height=10.50
Surface Area: 1102.50, Volume: 2315.25
*/
