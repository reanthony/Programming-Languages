#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Shape.h"
#include "Sphere.h"
#include "Cylinder.h"
#include "Cone.h"
#include "Cuboid.h"
#include "reading.h"
#include <string>
#include <functional>
#include <algorithm>

using namespace std;

std::vector<Shape*> *readFrom(string filename)  {
    string name;
    string type;
    //int num_shapes = 10;
    std::string line;
    ifstream ifss (filename, std::ifstream::in);
    char c;
    long num_shapes = 0;
    while (ifss.get(c))
    if (c == '\n')
        ++num_shapes;
    ifss.close();
    ifstream ifs (filename, std::ifstream::in);
    vector<Shape*> *shapes = new vector<Shape*>;
    double r, h, l, w;
    for (int i = 0; i < num_shapes; i++) {
        ifs >> name;
        //cout << name << "\n";
        ifs >> type;
        //cout << type << "\n";
        if (type == "sphere") {
            ifs >> r;
            shapes->push_back(new Sphere(name, r));
        }
        if (type == "cylinder")  {
            ifs >> r >> h;
            shapes->push_back(new Cylinder(name, r, h));
        }	
        if (type == "cone")  {
            ifs >> r >> h;
            shapes->push_back(new Cone(name, r, h));
        }	
        if (type == "cuboid")  {
            ifs >> l >> w >> h;
            shapes->push_back(new Cuboid(name, l, w, h));
        }
	}
	ifs.close();
	return shapes; 
}

