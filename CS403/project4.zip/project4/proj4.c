/*Eland Anthony Project 4:
To read a file of text and generate a cipher of the file*/

#include <stdio.h>
#include <string.h>

int inputValid(char * inputS);
void goUp(char * inputS);
void goDown(char * inputS);
void goLeft(char * inputS);
void goRight(char * inputS);
int main(int argc, char *argv[])
{
	FILE *fp;
	char inputS[30];
	char *input;
	int i;
	if(argc != 3)
		{
		printf("Usage: %s <inputfile> <combination of I D L R> \n" , argv[0]);
		return 1;
		}
	input = argv[2];
	if(!inputValid(input))  {
	printf("Invalid input. You must use a combination of I D L or R\n" );
	return 1;
				}
	fp = fopen(argv[1], "r");
	if(fp == NULL)  {
		printf("Could not open file %s\n", argv[0]);
		return 1;
			}
	fscanf(fp, "%s", inputS);
	while( !feof(fp))  {
		for(i = 0; input[i] != '\0'; ++i)  {
			switch(input[i]) {

				case 'I':
				goUp(inputS);
				break;
				case 'D':
				goDown(inputS);
				break;
				case 'L':
				goLeft(inputS);
				break;
				case 'R':
				goRight(inputS);
				break;

					}
						}
	printf("%s\n", inputS);
	fscanf(fp, "%s", inputS);
			}
	fclose(fp);
}
	int inputValid(char *inputS)  {
	int i;
	char letter;
	for(i = 0; inputS[i] != '\0'; ++i)  {
		letter= inputS [i];
		if(letter!= 'I' && letter!= 'D' && letter!= 'L' && letter!= 'R')
			return 0;
					}
	return 1;
					}
void goUp(char *inputS)  {
	char letter;
	int i;
	for(i = 0; inputS[i] != '\0'; ++i)  {
	letter= inputS[i];
	if(letter>= 'a' && letter<= 'z')  {
		++letter;
		if(letter> 'z') 
			letter= 'a';
					}
		else if(letter>= 'A' && letter<= 'Z')  {
			++letter;
			if(letter> 'Z') 
				letter= 'A';
							}
else if (letter>= '0' && letter<= '9')  {
	++letter;
	if(letter> '9') 
		letter= '0';
					}
inputS[i] = letter;
					}
			}
void goDown(char *inputS)  {
	char letter;
	int i;
	for(i = 0; inputS[i] != '\0'; i++)  {
		letter= inputS[i];
		if(letter>= 'a' && letter<= 'z')  {
			--letter;
		if(letter< 'a')
			letter= 'z';
						}
else if (letter<= '9' && letter>= '0')  {
	--letter;
	if(letter< '0') 
		letter= '9';
					}
else if(letter>= 'A' && letter<= 'Z')  {
	--letter;
	if(letter< 'A') 
		letter= 'Z';
					}
	inputS[i] = letter;
						}
			}
void goLeft(char *inputS)  {
	int i;
	char let2 = inputS[0]; 
	for (i = 1; inputS[i] != '\0'; ++i)
		inputS[i-1] = inputS[i];
	inputS[i-1] = let2;
			}
void goRight(char *inputS)  {
	int len = strlen(inputS);
	char fin = inputS[len-1]; 
	int i;
	for (i = len-1; i > 0 ; --i)
		inputS[i] = inputS[i - 1];
	inputS[0] = fin;
			}


