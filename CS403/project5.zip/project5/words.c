/* Eland Anthony - CS100
Program to find words and how they're represented  in a matrix*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int leftRight(char *curChars, int totsize, char inp[364], char **out){
	int i,m,q;
	int len = strlen(inp) - 1;
	int dDex = 0;
	int crct = 0;
	for(i=0;i<totsize;i++){
		dDex = 0;   
		for(m=0;m<totsize;m++){
			if(curChars[i*totsize+m] == inp[dDex]){
				dDex++;
			}else if(curChars[i*totsize+m] == inp[0]){
				dDex = 1;
			}else {
				dDex = 0;
			}
			if(dDex == len){
				q = m;
				while(dDex > 0){
					out[i][q] = inp[dDex-1];;
					--q;
					--dDex;
				}
				crct++;
			}
			}
	}
	return crct;
}
int upDown(char *curChars, int totsize, char inp[364], char **out){
	int i,m,q;
	int len = strlen(inp) - 1;
	int dDex = 0;
	int crct = 0;
	for(m=0;m<totsize;m++){
		dDex = 0;   
		for(i=0;i<totsize;i++){
			if(curChars[i*totsize+m] == inp[dDex]){
				dDex++;
			}else if(curChars[i*totsize+m] == inp[0]){
				dDex = 1;
			}else {
				dDex = 0;
			}
			if(dDex == len){
				q = i;
				while(dDex > 0){
					out[q][m] = inp[dDex-1];;
					dDex--;
					q--;
				}
				crct++;
			}
		}
	}
	return crct;
}
int downUp(char *curChars, int totsize, char inp[364], char **out){
	int i,m,q;
	int len = strlen(inp) - 1;
	int dDex = 0;
	int crct = 0;
	for(m=0;m<totsize;m++){
		dDex = 0;   
		for(i=totsize-1;i>=0;i--){
			if(curChars[i*totsize+m] == inp[dDex]){
				dDex++;

			}else if(curChars[i*totsize+m] == inp[0]){
				dDex = 1;
			}else {
				dDex = 0;
			}
			if(dDex == len){
				q = i;
				while(dDex > 0){
					out[q][m] = inp[dDex-1];
					dDex--;
					q++;
				}
				crct++;
			}
		}
	}
	return crct;
}
int rightLeft(char *curChars, int totsize, char inp[364], char **out){

	int i,m,q;
	int len = strlen(inp) - 1;
	int dDex = 0;
	int crct = 0;
	for(i=0;i<totsize;i++){
		dDex = 0;   
		for(m=totsize-1;m>=0;m--){
			if(curChars[i*totsize+m] == inp[dDex]){
				dDex++;
			}else if(curChars[i*totsize+m] == inp[0]){
				dDex = 1;
			}else {
				dDex = 0;
			}
			if(dDex == len){
				q = m;
				while(dDex > 0){
					out[i][q] = inp[dDex-1];;
					dDex--;
					q++;
				}
				crct++;
			}
		}

	}
	return crct;
}
int main(int argc, char ** argv) {
	int var1, var2, var3, var4;
	if(argc != 3){
		printf("Please pass two arguments. 1. Integer 2. File which contains a puzzle ");
		return -1;
	}
	int totsize = atoi(argv[1]);
	char curChars[totsize][totsize];
	int i,m;
	char inp[364];
	char **out = (char**)malloc(sizeof(char*)*totsize);
	for(i =0 ; i <totsize;i++)
		*(out+i) = (char*)malloc(sizeof(char)*totsize);
	for(i=0;i<totsize;i++){
		for(m=0;m<totsize;m++){
			out[i][m]='.';
		}
	}
	FILE *file = fopen(argv[2], "r");
	while(!feof(file)){
		for (int x=0;x<totsize;x++){
			for (int y=0;y<totsize;y++){
				fscanf(file, " %c", &curChars[x][y]);
			}
		}
	}
	fclose(file);
	printf("The puzzle is: \n");
	for(i=0;i<totsize;i++){
		printf("\t");
		for(m=0;m<totsize;m++){
			printf("%c\t",curChars[i][m]);
		}
		printf("\n");
	}
	char *cut="zzz\n";
	printf("\nEnter a word to find in the puzzle: ");
	fgets(inp, sizeof inp, stdin);
	while (!(strcmp(inp,cut)==0)){
		var1 = leftRight((char*)curChars,totsize,inp, out);
		var2 = upDown((char*)curChars,totsize,inp, out);
		var3 = downUp((char*)curChars,totsize,inp, out);
		var4 = rightLeft((char*)curChars,totsize,inp, out);
		int sum = var1+var2+var3+var4;
		inp[strlen(inp)-1] = '\0';
		printf("\nThe word %s was found %d times, as shown below\n",inp,sum);
		printf("\t%d times written left-to-right\n", var1);
		printf("\t%d times written top-to-bottom\n", var2);
		printf("\t%d times written bottom-to-top\n", var3);
		printf("\t%d times written right-to-left\n", var4);
		for(i=0;i<totsize;i++){
			printf("\t");
			for(m=0;m<totsize;m++){
				printf("%c",out[i][m]);
			}
			printf("\n");
		}
		printf("Enter another word to find (or 'zzz' to exit) : ");
		fgets(inp, sizeof inp, stdin);
		for(i=0;i<totsize;i++){
			for(m=0;m<totsize;m++){
				out[i][m]='.';
			}
		}

	}
}

