/* Eland Anthony - CS 100 
Program to reverse and print input to a fixed line width*/

#include <stdio.h>
#include <string.h>
int main()
{
int width;
char output[100]; 
char word[100];
int idx, len, lineStart, lineEnd, k;  
  
printf("Enter the output line length: ");
scanf("%d", &width);
printf("Enter your text(control-d to exit)\n");
  
lineStart = 0;
lineEnd = width;
idx = lineEnd - 1; 
  
  
while(scanf("%s", word) == 1) 
{
len = strlen(word);
  
if(idx - len + 1 < lineStart) 
{
while(idx >= lineStart)
output[idx--] = ' ';
output[lineEnd] = '\n'; 
lineStart = lineEnd + 1; 
lineEnd = lineStart + width; 
idx = lineEnd - 1; 
}
  
for(k =0; k < len; k++)
output[idx--] = word[k];
  
if(idx > lineStart) 
output[idx--] = ' ';
  
}
  
while(idx >= lineStart)
output[idx--] = ' ';
  
output[lineEnd] = '\0'; //terminate with null character
printf("\n%s\n" ,output);
  
}
