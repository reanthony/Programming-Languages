list(Lower, Upper, List) :- findall([F, L], (bill(F, L, Z), Z>=Lower, Z=<Upper), List).
count(Lower, Upper, Count) :- findall(Z, (bill(F, L, Z), Z>=Lower, Z=<Upper), List), length(List, Count).