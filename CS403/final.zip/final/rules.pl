bill(First, Last, Total) :- subscriber(First, Last, Type, Gigs),
	Type='basic', 
	Total is 5 * Gigs + 10.

bill(First, Last, Total) :- subscriber(First, Last, Type, Gigs),
	Type='unlimited', 
	Total is 40.

bill(First, Last, Total) :- subscriber(First, Last, Type, Gigs),
	Type='value', Temp is Gigs - 5, Temp > 0, 
	Total is Temp * 3 + 25.

bill(First, Last, Total) :- subscriber(First, Last, Type, Gigs),
	Type='value', Temp is Gigs - 5, Temp =< 0, 
	Total is 25.