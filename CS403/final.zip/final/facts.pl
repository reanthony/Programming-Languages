subscriber('Noah', 'Johnson', 'basic', 3).
subscriber('William', 'Smith', 'unlimited', 15.4).
subscriber('Emma', 'Wilson', 'value', 5).
subscriber('Elijah', 'Brown', 'value', 8.5).
subscriber('Olivia', 'Harvey', 'unlimited', 9.2).
subscriber('Mason', 'Lee', 'basic', 5.4).
subscriber('Lucas', 'Miller', 'value', 12).
