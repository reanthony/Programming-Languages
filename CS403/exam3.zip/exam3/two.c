#include <stdio.h>
#include <stdlib.h>

int sumBorders(int **matrix, int size)  {
	int answer = 0;
	if (size>1){
		if (size==2){
		for (int i = 0; i<size; i++){
			for(int k = 0; k<size; k++){
				answer+=matrix[i][k];
				}
			}
	           }
		else {
		int final= size-1;
		int finalRow= size-1;
		for (int i = 0; i<1; i++){
                                for(int k = 0; k<size; k++){
                                answer+=matrix[i][k];
                                }
                        }
		for (int i = finalRow; i<size; i++){
                                for(int k = 0; k<size; k++){
                                answer+=matrix[i][k];
                                }
                        }
		for (int i = 1; i<size-1; i++){
                                for(int k = 0; k<1; k++)  {
                                answer+=matrix[i][k];
                                }

                        }
		for (int i = 1; i<size-1; i++){
                                for(int k = final; k<size; k++)  {
                                answer+=matrix[i][k];
                                }
                	 }
		}
	}
	else{
		answer+=matrix[0][0];
	}



	return answer;
}
int main(int argc, char *argv[]) {
    FILE *fp = fopen(argv[1], "r");
    int size = atoi(argv[2]);
    int **matrix = malloc(sizeof(int *) * size);
    for (int a=0; a<size; a++)
        matrix[a] = malloc(sizeof(int) * size);
    for (int a=0; a<size; a++)
        for (int b=0; b<size; b++)
            fscanf(fp, "%d", &matrix[a][b]);
    int answer = sumBorders(matrix, size);
    printf("The answer is %d\n", answer);
    return 0;
}
