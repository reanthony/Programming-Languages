#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (int argc, char *argv[]){
	char enter;
	printf("Enter a character (or <control-d> to exit) :\n");
	scanf("%c", &enter);
	while (!feof(stdin))  {
	int totals=0;
		
	for (int count =1; count<argc; count++)  {
			
		for (int len=strlen(argv[count])+1; len>=0;--len)  {
				
			if (argv[count][len] == enter)  {
					totals+=1;
			}
			}	
			}
		printf("%c occurs %d times\n", enter, totals);
		printf("Enter a character (or <control-d> to exit) :\n");
		scanf(" %c", &enter);
	}
	return 0;
}

