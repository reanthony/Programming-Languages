
/*Eland Anthony
Input/Output Project 1 Dollars and Coins */
#include <stdio.h>

int main(void) {
	
	//initialize coins
	int twenties;
	int tens;
	int fives;
	int ones;
	int quarters;
	int dimes;
	int nickles;
	int pennies;
	
	//print prompt  and scan for entries
	printf("Enter the number of $20s you have:\n");
	scanf("%d",&twenties);
	printf("Enter the number of $10s you have:\n");
	scanf("%d",&tens);
	printf("Enter the number of $5s you have:\n");
	scanf("%d",&fives);
	printf("Enter the number of $1s you have:\n");
	scanf("%d",&ones);
	printf("Enter the number of quarters you have:\n");
	scanf("%d",&quarters);
	printf("Enter the number of dimes you have:\n");
	scanf("%d",&dimes);
	printf("Enter the number of nickles you have:\n");
	scanf("%d",&nickles);
	printf("Enter the number of pennies you have:\n");
	scanf("%d",&pennies);
	
	//totaling coins and dollars in terms of cents and dollars	
	int totalDollars = twenties * 20 + tens * 10 + fives * 5 + ones;
	int totalCents = quarters * 25 + dimes * 10 + nickles * 5 + pennies;
	int totalDollarAmt = twenties + tens + fives + ones;
	int totalCoinsAmt = quarters + dimes + nickles + pennies;
	
	//find grams in terms of  dollars and coins
	int dollarsGram = totalDollarAmt;
	double coinsGram = 2.5 * pennies + 5 * nickles + 2.268 * dimes + 5.670 * quarters;
	double pounds = 0.00220462;	

	//find weight in pounds
	double dollarsPound = dollarsGram * pounds;
	double coinsPound = coinsGram * pounds;
	double totalPound = coinsPound + dollarsPound; 	

	//output 
	printf("You have %d dollars in bills and %d cents in change.\n", totalDollars, totalCents);
	printf("The weight of your bills is %f pounds.\n", dollarsPound);
	printf("The weight of your change is %f pounds.\n", coinsPound);
	printf("Your money can go a total of %f pounds.\n", totalPound);  

		}
